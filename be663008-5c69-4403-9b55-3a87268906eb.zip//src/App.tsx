import { Tldraw } from "tldraw";
import "tldraw/tldraw.css";
import "./styles.css";

export default function App() {
  return (
    <div style={{ position: "fixed", inset: 0 }}>
      <Tldraw
        persistenceKey="tldraw-example"
        onMount={(editor) => {
          // You can use the app API here!
          editor.selectAll();
        }}
      />
    </div>
  );
}
